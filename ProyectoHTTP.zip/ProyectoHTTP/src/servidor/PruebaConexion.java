
package servidor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PruebaConexion {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/logistica32";
        String usuario = "root";
        String contrasena = "";

        String sql = "SELECT id, dni, nombre, apellido, edad, correo "
                   + "FROM persona";

        try {
            Connection conexion = DriverManager.getConnection(
                    url, usuario, contrasena
            );

            System.out.println("¡Conexión exitosa a MySQL!");

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            ResultSet resultado = sentencia.executeQuery();

            while (resultado.next()) {

                int id = resultado.getInt("id");
                int dni = resultado.getInt("dni");
                String nombre = resultado.getString("nombre");
                String apellido = resultado.getString("apellido");
                int edad = resultado.getInt("edad");
                String correo = resultado.getString("correo");

                System.out.println("ID: " + id);
                System.out.println("DNI: " + dni);
                System.out.println("Nombre: " + nombre);
                System.out.println("Apellido: " + apellido);
                System.out.println("Edad: " + edad);
                System.out.println("Correo: " + correo);

                System.out.println("--------------------------");
            }

            resultado.close();
            sentencia.close();
            conexion.close();

        } catch (SQLException e) {
            System.out.println("Error al consultar la base de datos:");
            e.printStackTrace();
        }
    }
}
