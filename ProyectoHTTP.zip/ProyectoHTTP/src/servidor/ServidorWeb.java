
package servidor;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.sql.CallableStatement;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServidorWeb {

    public static void main(String[] args) throws IOException {

        HttpServer servidor = HttpServer.create(
                new InetSocketAddress(8080), 0
        );

        servidor.createContext("/", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto HTML/CSS: " + ruta);
                Path archivo = null;
                if (ruta.equals("/")) {
                    archivo = Paths.get("src", "Web", "VistaGeneral.html");
                }
                System.out.println("Archivo: " + (archivo != null ? archivo.toAbsolutePath() : "No definido"));

                System.out.println("Existe: " + (archivo != null && Files.exists(archivo)));

                byte[] contenido;
                int codigo;

                if (archivo != null && Files.exists(archivo)) {
                    contenido = Files.readAllBytes(archivo);
                    codigo = 200;
                    if (ruta.equals("/estilos.css")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/css; charset=UTF-8"
                        );

                    }else{
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/html; charset=UTF-8"
                        );
                    }
                } else {
                    String mensaje = "Archivo no encontrado";
                    contenido = mensaje.getBytes(
                            StandardCharsets.UTF_8
                    );
                    codigo = 404;
                    intercambio.getResponseHeaders().set(
                            "Content-Type",
                            "text/plain; charset=UTF-8"
                    );
                }
                intercambio.sendResponseHeaders(
                        codigo, contenido.length
                );
                try (OutputStream salida =
                        intercambio.getResponseBody()) {

                    salida.write(contenido);
                }
            }
        });
        servidor.createContext("/api/usuarios", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de usuario: " + ruta);
    
    if (!ruta.equals("/api/usuarios")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "SELECT id_usuario, nombre, apellido, email, contrasenia FROM usuarios";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        PreparedStatement sentencia = conexion.prepareStatement(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            // El ID es un número, va sin comillas externas
            json.append("\"id\":").append(resultado.getInt("id_usuario")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\",");
            json.append("\"apellido\":\"").append(escaparJson(resultado.getString("apellido"))).append("\",");
            json.append("\"email\":\"").append(escaparJson(resultado.getString("email"))).append("\",");
            json.append("\"contrasenia\":\"").append(escaparJson(resultado.getString("contrasenia"))).append("\"");
            
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
      servidor.createContext("/api/Adheridos", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de adheridos: " + ruta);
    
    if (!ruta.equals("/api/Adheridos")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_adheridos()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_empresa")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\",");
            json.append("\"cuit\":\"").append(escaparJson(resultado.getString("cuit"))).append("\",");
            json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
            json.append("\"telefono\":\"").append(escaparJson(resultado.getString("telefono"))).append("\",");
            json.append("\"rubro\":\"").append(escaparJson(resultado.getString("rubro"))).append("\",");
            json.append("\"duenio\":\"").append(escaparJson(resultado.getString("duenio"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
        servidor.createContext("/api/Productos", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de productos: " + ruta);
    
    if (!ruta.equals("/api/Productos")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_productos()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Producto")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"marca\":\"").append(escaparJson(resultado.getString("marca"))).append("\",");
            json.append("\"descripcion\":\"").append(escaparJson(resultado.getString("descripcion"))).append("\",");
            json.append("\"precio\":\"").append(escaparJson(resultado.getString("precio"))).append("\",");
            json.append("\"stock\":\"").append(escaparJson(resultado.getString("stock"))).append("\",");
            json.append("\"categoria\":\"").append(escaparJson(resultado.getString("categoria"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
        servidor.createContext("/api/Paquetes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Paquetes: " + ruta);
    
    if (!ruta.equals("/api/Paquetes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_paquetes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Paquete")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"peso\":\"").append(escaparJson(resultado.getString("peso"))).append("\",");
            json.append("\"volumen\":\"").append(escaparJson(resultado.getString("volumen"))).append("\",");
            json.append("\"ensamble\":\"").append(escaparJson(resultado.getString("fecha_ensamble"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         servidor.createContext("/api/Ciudades", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Ciudades: " + ruta);
    
    if (!ruta.equals("/api/Ciudades")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_ciudades()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Ciudad")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("Nombre"))).append("\",");
            json.append("\"provincia\":\"").append(escaparJson(resultado.getString("Provincia"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         
         servidor.createContext("/api/ProduPaque", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de ProduPaque: " + ruta);
    
    if (!ruta.equals("/api/ProduPaque")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_productos_paquetes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Propa")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"ID_producto\":\"").append(escaparJson(resultado.getString("ID_Producto"))).append("\",");
            json.append("\"ID_Paquete\":\"").append(escaparJson(resultado.getString("ID_Paquete"))).append("\",");
            json.append("\"cantidad\":\"").append(escaparJson(resultado.getString("cantidad"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         servidor.createContext("/api/Clientes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Clientes: " + ruta);
    
    if (!ruta.equals("/api/Clientes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_clientes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Cliente")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("Nombre"))).append("\",");
            json.append("\"apellido\":\"").append(escaparJson(resultado.getString("Apellido"))).append("\",");
            json.append("\"dni\":\"").append(escaparJson(resultado.getString("DNI"))).append("\",");
            json.append("\"email\":\"").append(escaparJson(resultado.getString("email"))).append("\",");
            json.append("\"telefono\":\"").append(escaparJson(resultado.getString("telefono"))).append("\",");
            json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
            json.append("\"postal\":\"").append(escaparJson(resultado.getString("cod_postal"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         servidor.createContext("/api/Envios", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Envios: " + ruta);
    
    if (!ruta.equals("/api/Envios")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_envios()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Envio")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"fecha\":\"").append(escaparJson(resultado.getString("Fecha"))).append("\",");
            json.append("\"origen\":\"").append(escaparJson(resultado.getString("Origen"))).append("\",");
            json.append("\"destino\":\"").append(escaparJson(resultado.getString("Destino"))).append("\",");
            json.append("\"empresa\":\"").append(escaparJson(resultado.getString("ID_Empresa"))).append("\",");
            json.append("\"estado\":\"").append(escaparJson(resultado.getString("estado"))).append("\",");
            json.append("\"cliente\":\"").append(escaparJson(resultado.getString("ID_Cliente"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
        servidor.createContext("/api/Empleados", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Empleados: " + ruta);
    
    if (!ruta.equals("/api/Empleados")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_empleados()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Empleado")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("Nombre"))).append("\",");
            json.append("\"apellido\":\"").append(escaparJson(resultado.getString("Apellido"))).append("\",");
            json.append("\"dni\":\"").append(escaparJson(resultado.getString("Dni"))).append("\",");
            json.append("\"email\":\"").append(escaparJson(resultado.getString("email"))).append("\",");
            json.append("\"telefono\":\"").append(escaparJson(resultado.getString("telefono"))).append("\",");
            json.append("\"sector\":\"").append(escaparJson(resultado.getString("sector"))).append("\",");
            json.append("\"cargo\":\"").append(escaparJson(resultado.getString("cargo"))).append("\",");
            json.append("\"rol\":\"").append(escaparJson(resultado.getString("rol"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
        servidor.createContext("/api/Vehiculos", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Vehiculos: " + ruta);
    
    if (!ruta.equals("/api/Vehiculos")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_vehiculos()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Vehiculo")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"precio\":\"").append(escaparJson(resultado.getString("Precio"))).append("\",");
            json.append("\"anio\":\"").append(escaparJson(resultado.getString("anio"))).append("\",");
            json.append("\"empleado\":\"").append(escaparJson(resultado.getString("ID_Empleado"))).append("\",");
            json.append("\"modelo\":\"").append(escaparJson(resultado.getString("Modelo"))).append("\",");
            json.append("\"marca\":\"").append(escaparJson(resultado.getString("Marca"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/VehiEnvi", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Union: " + ruta);
    
    if (!ruta.equals("/api/VehiEnvi")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_envio_vehiculo()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_EV")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"Envio\":\"").append(escaparJson(resultado.getString("ID_Envio"))).append("\",");
            json.append("\"Vehiculo\":\"").append(escaparJson(resultado.getString("ID_Vehiculo"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/VehiPaq", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Union: " + ruta);
    
    if (!ruta.equals("/api/VehiPaq")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_envios_paquetes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_ep")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"Envio\":\"").append(escaparJson(resultado.getString("ID_Envio"))).append("\",");
            json.append("\"Paquete\":\"").append(escaparJson(resultado.getString("ID_Paquete"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/Reportes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Reporte: " + ruta);
    
    if (!ruta.equals("/api/Reportes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_reportes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Reporte")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"detalle\":\"").append(escaparJson(resultado.getString("detalle"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/Tickets", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Ticket: " + ruta);
    
    if (!ruta.equals("/api/Tickets")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_tickets()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Ticket")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"Cliente\":\"").append(escaparJson(resultado.getString("ID_Cliente"))).append("\",");
            json.append("\"Fecha\":\"").append(escaparJson(resultado.getString("fecha"))).append("\",");
            json.append("\"Detalle\":\"").append(escaparJson(resultado.getString("detalle"))).append("\",");
            json.append("\"Total\":\"").append(escaparJson(resultado.getString("total"))).append("\",");
            json.append("\"Pago\":\"").append(escaparJson(resultado.getString("metodospago"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/RepoTicket", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Union: " + ruta);
    
    if (!ruta.equals("/api/RepoTicket")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_reportesTickets()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_rt")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
           
            json.append("\"Ticket\":\"").append(escaparJson(resultado.getString("ID_Ticket"))).append("\",");
            json.append("\"Reporte\":\"").append(escaparJson(resultado.getString("ID_Reporte"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/Almacenes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Almacenes: " + ruta);
    
    if (!ruta.equals("/api/Almacenes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "select * from almacenes;";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        PreparedStatement sentencia = conexion.prepareStatement(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Almacen")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
           
            json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
            json.append("\"ciudad\":\"").append(escaparJson(resultado.getString("ciudad"))).append("\",");
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
        //Iniciamos el servidor
        
        servidor.start();
        System.out.println("Servidor iniciado en http://localhost:8080");
    }
    
    private static String escaparJson(String texto) {

        if (texto == null) {
            return "";
        }

        return texto
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static void enviarRespuesta(
            HttpExchange intercambio,
            int codigo,
            String respuesta
    ) throws IOException {

        byte[] contenido = respuesta.getBytes(
                StandardCharsets.UTF_8
        );

        intercambio.getResponseHeaders().set(
                "Content-Type",
                "application/json; charset=UTF-8"
        );

        intercambio.sendResponseHeaders(
                codigo, contenido.length
        );

        try (OutputStream salida =
                intercambio.getResponseBody()) {

            salida.write(contenido);
        }
    }
}
