
package servidor;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.sql.CallableStatement;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServidorWeb {

    public static void main(String[] args) throws IOException {

        HttpServer servidor = HttpServer.create(
                new InetSocketAddress(8080), 0
        );

        servidor.createContext("/", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto HTML/CSS: " + ruta);
                Path archivo = null;
                if (ruta.equals("/")) {
                    archivo = Paths.get("src", "Web", "index.html");
                }else if(ruta.equals("/index(admin).html")){
                    archivo = Paths.get("src", "Web", "index(admin).html");
                }else if(ruta.equals("/auxiliar.html")){
                    archivo = Paths.get("src", "Web", "AuxiliarCuentas.html");
                }else if(ruta.equals("/VerEnvios.html")){
                    archivo = Paths.get("src", "Web", "VerEnvios.html");
                }else if(ruta.equals("/Inicio_sesion.html")){
                    archivo = Paths.get("src", "Web", "Inicio_sesion.html");
                }else if(ruta.equals("/CrearEnvio.html")){
                    archivo = Paths.get("src", "Web", "CrearEnvio.html");
                }else if(ruta.equals("/VerEnvio.html")){
                    archivo = Paths.get("src", "Web", "VerEnvio.html");
                }else if(ruta.equals("/registrarEmpresasAdheridas.html")){
                    archivo = Paths.get("src", "Web", "registrarEmpresasAdheridas.html");
                }else if(ruta.equals("/Crear.html")){
                    archivo = Paths.get("src", "Web", "Crear.html");
                }else if(ruta.equals("/registrarVehiculos.html")){
                    archivo = Paths.get("src", "Web", "registrarVehiculos.html");
                }else if (ruta.equals("/VistaGeneral.html")){
                    archivo = Paths.get("src", "Web", "VistaGeneral.html");
                }else if(ruta.equals("/Registrar Paquete.html")){
                    archivo = Paths.get("src", "Web", "Registrar Paquete.html");
                }else if(ruta.equals("/Mostrar Paquete.html")){
                    archivo = Paths.get("src", "Web", "Mostrar Paquete.html");
                }else if(ruta.equals("/EditarPaquete.html")){
                    archivo = Paths.get("src", "Web", "EditarPaquete.html");
                }else if(ruta.equals("/Crear.html")){
                    archivo = Paths.get("src", "Web", "Crear.html");
                }else if(ruta.equals("/Inicio_sesion.html")){
                    archivo = Paths.get("src", "Web", "Inicio_sesion.html");         
                }else if(ruta.equals("/Mostrar Vehiculo.html")){
                    archivo = Paths.get("src", "Web", "Mostrar Vehiculo.html");
                }else if(ruta.equals("/Mostrar Empresa_adheridas.html")){
                    archivo = Paths.get("src", "Web", "Mostrar Empresa_adheridas.html");
                }else if(ruta.equals("/Editar Adheridos.html")){
                    archivo = Paths.get("src", "Web", "Editar Adheridos.html");
                }else if (ruta.equals("/Crear.css")) {
                    archivo = Paths.get("src", "Web", "Crear.css");
                }else if (ruta.equals("/Inicio_sesion.css")) {
                    archivo = Paths.get("src", "Web", "Inicio_sesion.css");
                }else if (ruta.equals("/general.css")) {
                    archivo = Paths.get("src", "Web", "general.css");
                }else if (ruta.equals("/CrearEmpleado.html")) {
                    archivo = Paths.get("src", "Web", "CrearEmpleado.html");
                }else if (ruta.equals("/Mostrar Empleado.html")) {
                    archivo = Paths.get("src", "Web", "Mostrar Empleado.html");
                }else if (ruta.equals("/EditarEmpleado.html")) {
                    archivo = Paths.get("src", "Web", "EditarEmpleado.html");
                }else if (ruta.equals("/RegistrarCliente.html")) {
                    archivo = Paths.get("src", "web", "RegistrarCliente.html");
                }else if (ruta.equals("/VerClientes.html")) {
                    archivo = Paths.get("src", "web", "VerClientes.html");
                }else if (ruta.equals("/EditarCliente.html")) {
                    archivo = Paths.get("src", "web", "EditarCliente.html");
                }else if (ruta.equals("/2.html")) {
                    archivo = Paths.get("src", "Web", "crearProduct.html");
                }else if (ruta.equals("/mostrarProductos.html")) {
                    archivo = Paths.get("src", "Web", "mostrarProductos.html");
                }
                System.out.println("Archivo: " + (archivo != null ? archivo.toAbsolutePath() : "No definido"));

                System.out.println("Existe: " + (archivo != null && Files.exists(archivo)));

                byte[] contenido;
                int codigo;

                if (archivo != null && Files.exists(archivo)) {
                    contenido = Files.readAllBytes(archivo);
                    codigo = 200;
                    if (ruta.equals("/Crear.css")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/css; charset=UTF-8"
                        );

                    }else if (ruta.equals("/Inicio_sesion.css")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/css; charset=UTF-8"
                        );

                    }else if (ruta.equals("/general.css")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/css; charset=UTF-8"
                        );

                    }else{
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/html; charset=UTF-8"
                        );
                    }
                } else {
                    String mensaje = "Archivo no encontrado";
                    contenido = mensaje.getBytes(
                            StandardCharsets.UTF_8
                    );
                    codigo = 404;
                    intercambio.getResponseHeaders().set(
                            "Content-Type",
                            "text/plain; charset=UTF-8"
                    );
                }
                intercambio.sendResponseHeaders(
                        codigo, contenido.length
                );
                try (OutputStream salida =
                        intercambio.getResponseBody()) {

                    salida.write(contenido);
                }
            }
        });
        servidor.createContext("/api/usuarios", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de usuario: " + ruta);
    
    if (!ruta.equals("/api/usuarios")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "SELECT id_usuario, nombre, apellido, email, contrasenia FROM usuarios";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        PreparedStatement sentencia = conexion.prepareStatement(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            // El ID es un número, va sin comillas externas
            json.append("\"id\":").append(resultado.getInt("id_usuario")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\",");
            json.append("\"apellido\":\"").append(escaparJson(resultado.getString("apellido"))).append("\",");
            json.append("\"email\":\"").append(escaparJson(resultado.getString("email"))).append("\",");
            json.append("\"contrasenia\":\"").append(escaparJson(resultado.getString("contrasenia"))).append("\"");
            
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
   // -------------------------------------------------------------------------------------------------------------------------
      servidor.createContext("/api/Adheridos", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de adheridos: " + ruta);
    
    if (!ruta.equals("/api/Adheridos")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_adheridos()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_empresa")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\",");
            json.append("\"cuit\":\"").append(escaparJson(resultado.getString("cuit"))).append("\",");
            json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
            json.append("\"telefono\":\"").append(escaparJson(resultado.getString("telefono"))).append("\",");
            json.append("\"rubro\":\"").append(escaparJson(resultado.getString("rubro"))).append("\",");
            json.append("\"duenio\":\"").append(escaparJson(resultado.getString("duenio"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
      servidor.createContext("/api/Adheridos/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }

                // Obtener los valores del formulario.
                String Nombre = datos.get("Nombre");
                String Cuil = datos.get("Cuil");
                String direccion = datos.get("direccion");
                String telefono = datos.get("telefono");
                String rubro = datos.get("rubro");
                String duenio = datos.get("duenio");

                // Validar los campos.
                if (Nombre == null || Cuil == null
                        || direccion == null || telefono == null 
                        || rubro == null || duenio == null || Nombre.trim().isEmpty()
                        || Cuil.trim().isEmpty()
                        || direccion.trim().isEmpty()
                        || telefono.trim().isEmpty()|| rubro.trim().isEmpty()
                        || duenio.trim().isEmpty()){
                        

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                

                // Preparar la consulta SQL.
                String sql = "INSERT INTO empresa_adherida "
                        + "(nombre, cuit, direccion,telefono,rubro,duenio) "
                        + "VALUES (?, ?, ?,?,?,?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/logistica32",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql)
                ) {
                    int telefono2=Integer.parseInt(telefono);
                    sentencia.setString(1, Nombre);
                    sentencia.setString(2,Cuil );
                    sentencia.setString(3, direccion);
                    sentencia.setInt(4, telefono2);
                    sentencia.setString(5, rubro);
                     sentencia.setString(6, duenio);
                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Adheridoo guardado correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar el Adheridoo\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });    
      
      servidor.createContext("/api/Adheridos/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id_empresa = Integer.parseInt(datos.get("id_empresa"));
                    String nombre = datos.get("nombre");
                    String cuit = datos.get("cuit");
                    String direccion = datos.get("direccion");
                    int telefono = Integer.parseInt(datos.get("telefono"));
                    String rubro = datos.get("rubro");
                    String dueño = datos.get("duenio");

                    
                    if (telefono <= 0) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE Empresa_Adherida SET nombre = ?, cuit = ?, "
                        + "direccion = ?, telefono = ?, "
                        + "rubro = ?, duenio = ?"
                        + "WHERE id_empresa = ?"
                    ;

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setString(1, nombre);
                        sentencia.setString(2, cuit);
                        sentencia.setString(3, direccion);
                        sentencia.setInt(4, telefono);
                        sentencia.setString(5, rubro);
                        sentencia.setString(6, dueño);
                        sentencia.setInt(7, id_empresa);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Persona actualizada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"telefono debe ser numero valido\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });
      
      servidor.createContext("/api/Adheridos/eliminar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id_empresa = Integer.parseInt(datos.get("id_empresa"));

                    if (id_empresa <= 0) {
                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"ID no valido\"}");
                        return;
                    }

                    String sql = "DELETE FROM Empresa_Adherida WHERE ID_empresa = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, id_empresa);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Empresa eliminada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al eliminar de la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"No se pudo procesar la solicitud\"}");
                }
            }
        });
      
      servidor.createContext("/api/Productos", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de productos: " + ruta);
    
    if (!ruta.equals("/api/Productos")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_productos()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Producto")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"marca\":\"").append(escaparJson(resultado.getString("marca"))).append("\",");
            json.append("\"descripcion\":\"").append(escaparJson(resultado.getString("descripcion"))).append("\",");
            json.append("\"precio\":\"").append(escaparJson(resultado.getString("precio"))).append("\",");
            json.append("\"stock\":\"").append(escaparJson(resultado.getString("stock"))).append("\",");
            json.append("\"categoria\":\"").append(escaparJson(resultado.getString("categoria"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
            
   // ------------------------------------------------------------------------------------------------------------------------------------
        });
      servidor.createContext("/api/registrarProductos/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }

                // Obtener los valores del formulario.
                String marca = datos.get("marca");
                String descripcion = datos.get("descripcion");
                String precio = datos.get("precio");
                String stock = datos.get("stock");
                String categoria = datos.get("categoria");
    
                // Validar los campos.
                if (marca == null || descripcion == null
                        || precio == null || stock == null 
                        || categoria == null  || marca.trim().isEmpty()
                        || descripcion.trim().isEmpty()
                        || precio.trim().isEmpty()
                        || stock.trim().isEmpty()|| categoria.trim().isEmpty()
                       ){
                        

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                

                // Preparar la consulta SQL.
                String sql = "INSERT INTO productos "
                        + "(marca, descripcion, precio,stock,categoria) "
                        + "VALUES (?, ?, ?,?,?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/logistica32",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql)
                ) {
                    int precio2=Integer.parseInt(precio);
                    int stock2=Integer.parseInt(stock);
                    sentencia.setString(1, marca);
                    sentencia.setString(2,descripcion );
                    sentencia.setInt(3, precio2);
                    sentencia.setInt(4, stock2 );
                    sentencia.setString(5, categoria);
                    
                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Producto guardado correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar el producto\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });    
        
        servidor.createContext("/api/Productos/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id_producto = Integer.parseInt(datos.get("ID_producto"));
                    String marca = datos.get("marca");
                    String descripcion =datos.get("descripcion");
                    int precio = Integer.parseInt(datos.get("precio"));
                    int stock = Integer.parseInt(datos.get("stock"));
                    String categoria = datos.get("categoria");
                   
                    
                    if (precio <= 0 || stock <= 0) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE productos SET marca = ?, "
                        + "descripcion = ?, precio = ?, "
                        + "stock = ?, categoria = ?"
                        + "WHERE ID_producto = ?"
                    ;

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setString(1, marca);
                        sentencia.setString(2, descripcion);
                        sentencia.setInt(3, precio);
                        sentencia.setInt(4, stock);
                        sentencia.setString(5, categoria);
                        sentencia.setInt(6, id_producto);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Producto actualizado correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro el producto\"}");
                        }
                    }

                
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });
      
    servidor.createContext("/api/Productos/eliminar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int idProducto = Integer.parseInt(datos.get("id"));

                    if (idProducto <= 0) {
                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"ID no valido\"}");
                        return;
                    }

                    String sql = "DELETE FROM productos WHERE ID_Producto = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, idProducto);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Producto eliminado correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro el producto\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al eliminar de la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"No se pudo procesar la solicitud\"}");
                }
            }
        });
      
   // ------------------------------------------------------------------------------------------------------------------------------------
        servidor.createContext("/api/Paquetes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Paquetes: " + ruta);
    
    if (!ruta.equals("/api/Paquetes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_paquetes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Paquete")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"peso\":\"").append(escaparJson(resultado.getString("peso"))).append("\",");
            json.append("\"volumen\":\"").append(escaparJson(resultado.getString("volumen"))).append("\",");
            json.append("\"fecha\":\"").append(escaparJson(resultado.getString("fecha_ensamble"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}});
            
servidor.createContext("/api/RegistrarPaquete/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }

                // Obtener los valores del formulario.
                String peso = datos.get("peso");
                String volumen = datos.get("volumen");
                String fecha = datos.get("fecha");
                System.out.println("Valor peso: " + peso);
                System.out.println("Valor volumen: " + volumen);
                System.out.println("Valor fecha: " + fecha);
                

                // Validar los campos.
                if (peso == null || volumen == null
                        || fecha == null || peso.trim().isEmpty()
                        || volumen.trim().isEmpty()
                        || fecha.trim().isEmpty()){
                        

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                

                // Preparar la consulta SQL.
                String sql = "INSERT INTO paquetes "
                        + "(peso, volumen, fecha_ensamble) "
                        + "VALUES (?, ?, ?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/logistica32",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql)
                ) {
                    double peso2=Double.parseDouble(peso);
                    double volumen2=Double.parseDouble(volumen);
                    sentencia.setDouble(1, peso2);
                    sentencia.setDouble(2,volumen2 );
                    sentencia.setString(3, fecha.trim());

                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Paquete guardado correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar el paquete\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });    

servidor.createContext("/api/Paquetes/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id = Integer.parseInt(datos.get("id"));
                    double peso = Double.parseDouble(datos.get("peso"));
                    double volumen = Double.parseDouble(datos.get("volumen"));
                    String fecha = datos.get("fecha");


                    if (peso <= 0 || volumen <= 0 || fecha.isEmpty()) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE paquetes SET peso = ?, volumen = ?, "
                            + "fecha_ensamble = ? WHERE ID_Paquete = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setDouble(1, peso);
                        sentencia.setDouble(2, volumen);
                        sentencia.setString(3, fecha);
                        sentencia.setInt(4, id);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Persona actualizada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"peso y volumen deben ser numeros validos\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });

servidor.createContext("/api/Paquetes/eliminar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id = Integer.parseInt(datos.get("id"));

                    if (id <= 0) {
                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"ID no valido\"}");
                        return;
                    }

                    String sql = "DELETE FROM paquetes WHERE ID_Paquete = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, id);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Persona eliminada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al eliminar de la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"No se pudo procesar la solicitud\"}");
                }
            }
        });
            
//-----------------------------------------------------------------------------------------------------------------------------------------------------  
            
            
        
         servidor.createContext("/api/Ciudades", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Ciudades: " + ruta);
    
    
  
    if (!ruta.equals("/api/Ciudades")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_ciudades()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Ciudad")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("Nombre"))).append("\",");
            json.append("\"provincia\":\"").append(escaparJson(resultado.getString("Provincia"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         
         servidor.createContext("/api/ProduPaque", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de ProduPaque: " + ruta);
    
    if (!ruta.equals("/api/ProduPaque")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_productos_paquetes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Propa")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"ID_producto\":\"").append(escaparJson(resultado.getString("ID_Producto"))).append("\",");
            json.append("\"ID_Paquete\":\"").append(escaparJson(resultado.getString("ID_Paquete"))).append("\",");
            json.append("\"cantidad\":\"").append(escaparJson(resultado.getString("cantidad"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         servidor.createContext("/api/Clientes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Clientes: " + ruta);
    
    if (!ruta.equals("/api/Clientes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_clientes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Cliente")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("Nombre"))).append("\",");
            json.append("\"apellido\":\"").append(escaparJson(resultado.getString("Apellido"))).append("\",");
            json.append("\"dni\":\"").append(escaparJson(resultado.getString("DNI"))).append("\",");
            json.append("\"email\":\"").append(escaparJson(resultado.getString("email"))).append("\",");
            json.append("\"telefono\":\"").append(escaparJson(resultado.getString("telefono"))).append("\",");
            json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
            json.append("\"postal\":\"").append(escaparJson(resultado.getString("cod_postal"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         servidor.createContext("/api/Clientes/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }
                // Obtener los valores del formulario.
                String nombre = datos.get("Nombre");
                String apellido = datos.get("Apellido");
                String dni = datos.get("DNI");
                String email=datos.get("Email");
                String telefono=datos.get("Telefono");
                String direccion=datos.get("Direccion");
                String postal=datos.get("Cod_Postal");

                // Validar los campos.
                if (nombre == null || apellido == null
                        || dni == null || email == null ||telefono == null ||direccion == null||postal == null||nombre.trim().isEmpty()
                        || apellido.trim().isEmpty()
                        || dni.trim().isEmpty()|| email.trim().isEmpty()|| telefono.trim().isEmpty()|| direccion.trim().isEmpty()|| postal.trim().isEmpty()){
                        

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                

                // Preparar la consulta SQL.
                String sql = "INSERT INTO clientes "
                        + "(Nombre, Apellido, DNI,email,telefono,direccion,cod_postal) "
                        + "VALUES (?, ?, ?,?,?,?,?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/logistica32",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql)
                ) {
                   int codigo=Integer.parseInt(postal);
                int Dni=Integer.parseInt(dni);
                int Telefono=Integer.parseInt(telefono);
                    sentencia.setString(1, nombre);
                    sentencia.setString(2,apellido );
                    sentencia.setInt(3, Dni);
                    sentencia.setString(4, email);
                     sentencia.setInt(5, Telefono);
                     sentencia.setString(6, direccion);
                     sentencia.setInt(7, codigo);
                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Cliente guardado correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar el Vehiculo\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });
         servidor.createContext("/api/Clientes/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int ID_Cliente = Integer.parseInt(datos.get("id"));
                    String nombre = datos.get("Nombre");
                    String Apellido = datos.get("Apellido");
                    int DNI= Integer.parseInt(datos.get("DNI"));
                    String email = datos.get("email");
                    int telefono = Integer.parseInt(datos.get("telefono"));
                    String direccion = datos.get("direccion");
                    int cod_postal = Integer.parseInt(datos.get("cod_postal"));

                    
                    if (telefono <= 0) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE Clientes SET Nombre = ?, Apellido = ?, "
                        + "DNI = ?, email = ?, "
                        + "telefono = ?, direccion = ?, "
                        + "cod_postal = ? "  
                        + "WHERE ID_Cliente = ?"
                    ;

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setString(1, nombre);
                        sentencia.setString(2, Apellido);
                        sentencia.setInt(3, DNI);
                        sentencia.setString(4, email);
                        sentencia.setInt(5, telefono);
                        sentencia.setString(6, direccion);
                        sentencia.setInt(7, cod_postal);
                        sentencia.setInt(8, ID_Cliente);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Cliente actualizado correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro el cliente\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"telefono y DNI deben ser numero validos\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });
         servidor.createContext("/api/Clientes/eliminar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id_empresa = Integer.parseInt(datos.get("id"));

                    if (id_empresa <= 0) {
                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"ID no valido\"}");
                        return;
                    }

                    String sql = "DELETE FROM clientes WHERE ID_Cliente = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, id_empresa);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Clienta eliminada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al eliminar de la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"No se pudo procesar la solicitud\"}");
                }
            }
        });
         
         //-------------------------------------------------------------
         servidor.createContext("/api/Envios", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Envios: " + ruta);
    
    if (!ruta.equals("/api/Envios")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_envios()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Envio")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"fecha\":\"").append(escaparJson(resultado.getString("Fecha"))).append("\",");
            json.append("\"origen\":\"").append(escaparJson(resultado.getString("Origen"))).append("\",");
            json.append("\"destino\":\"").append(escaparJson(resultado.getString("Destino"))).append("\",");
            json.append("\"empresa\":\"").append(escaparJson(resultado.getString("ID_Empresa"))).append("\",");
            json.append("\"estado\":\"").append(escaparJson(resultado.getString("estado"))).append("\",");
            json.append("\"cliente\":\"").append(escaparJson(resultado.getString("ID_Cliente"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         servidor.createContext("/api/Envios/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }
                   
                // Obtener los valores del formulario.
                String fecha = datos.get("Fecha");
                String Origen = datos.get("Origen");
                String Destino = datos.get("Destino");
                String Estado = datos.get("Estado");
                String Cliente = datos.get("Cliente");
                String Adherido = datos.get("Adherido");
                // Validar los campos.
                if (fecha == null || Origen == null
                        || Destino == null || Estado == null
                        || Cliente == null || Adherido == null || fecha.trim().isEmpty()
                        || Origen.trim().isEmpty()
                        || Destino.trim().isEmpty()
                        || Cliente.trim().isEmpty()
                        || Adherido.trim().isEmpty()) {

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                int origen;
                int destino;
                int cliente;
                int adherido;
                try {
                    origen = Integer.parseInt(Origen);
                    destino = Integer.parseInt(Destino);
                    cliente = Integer.parseInt(Cliente);
                    adherido = Integer.parseInt(Adherido);
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Origen,destino,cliente y adherido deben ser numeros enteros\"}");
                    return;
                }

                // Preparar la consulta SQL.
               String sql = "CALL verificar_envio(?, ?, ?, ?, ?, ?, ?)"; // Mantiene los 7 '?'

try (
    Connection conexion = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/logistica32",
            "root",
            ""
    );
     CallableStatement sentencia = conexion.prepareCall(sql);
) {
    sentencia.setString(1, fecha);
    sentencia.setInt(2, origen);
    sentencia.setInt(3, destino);
    sentencia.setInt(4, adherido);
    sentencia.setString(5, Estado);
    sentencia.setInt(6, cliente);
    
    // 1. Corregido: Registrar el séptimo parámetro como SALIDA (Ejemplo si devuelve Texto)
    sentencia.registerOutParameter(7, java.sql.Types.VARCHAR);

    sentencia.execute();
    
    // 2. Opcional: Puedes leer lo que te devolvió la base de datos
    String respuestaBD = sentencia.getString(7); 
    
    enviarRespuesta(intercambio, 201,
            "{\"mensaje\":\"Envio guardada correctamente\", \"detalle\":\"" + respuestaBD + "\"}");

} catch (SQLException e) {
    e.printStackTrace();
    enviarRespuesta(intercambio, 500,
            "{\"error\":\"Error al guardar en la base de datos\"}");
}

            }
        });
         
         
        servidor.createContext("/api/Empleados", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Empleados: " + ruta);
    
    if (!ruta.equals("/api/Empleados")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_empleados()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Empleado")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("Nombre"))).append("\",");
            json.append("\"apellido\":\"").append(escaparJson(resultado.getString("Apellido"))).append("\",");
            json.append("\"dni\":\"").append(escaparJson(resultado.getString("Dni"))).append("\",");
            json.append("\"email\":\"").append(escaparJson(resultado.getString("email"))).append("\",");
            json.append("\"telefono\":\"").append(escaparJson(resultado.getString("telefono"))).append("\",");
            json.append("\"sector\":\"").append(escaparJson(resultado.getString("sector"))).append("\",");
            json.append("\"cargo\":\"").append(escaparJson(resultado.getString("cargo"))).append("\",");
            json.append("\"rol\":\"").append(escaparJson(resultado.getString("rol"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
           servidor.createContext("/api/Empleados/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }
                   
                // Obtener los valores del formulario.
                String Nombre = datos.get("Nombre");
                String Apellido = datos.get("Apellido");
                String Dni = datos.get("Dni");
                String Email = datos.get("email");
                String Telefono = datos.get("telefono");
                String Sector = datos.get("sector");
                String Cargo = datos.get("cargo");
                String Rol = datos.get("rol");
                // Validar los campos.
                if (Nombre == null
                        || Apellido == null
                        || Dni == null
                        || Email == null
                        || Telefono == null
                        || Sector == null
                        || Cargo == null
                        || Rol == null
                        || Nombre.trim().isEmpty()
                        || Apellido.trim().isEmpty()
                        || Dni.trim().isEmpty()
                        || Email.trim().isEmpty()
                        || Telefono.trim().isEmpty()
                        || Sector.trim().isEmpty()
                        || Cargo.trim().isEmpty()
                        || Rol.trim().isEmpty()
                        ) {

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                int dni;
                int telefono;
               
                try {
                    dni = Integer.parseInt(Dni);
                    telefono = Integer.parseInt(Telefono);
                   
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El DNI y telefono deben ser numeros enteros\"}");
                    return;
                }

                // Preparar la consulta SQL.
               String sql = "CALL agregar_empleados(?, ?, ?, ?, ?, ?, ?, ?, ?)"; // Mantiene los 7 '?'

try (
    Connection conexion = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/logistica32",
            "root",
            ""
    );
     CallableStatement sentencia = conexion.prepareCall(sql);
) {
    sentencia.setString(1, Nombre);
    sentencia.setString(2, Apellido);
    sentencia.setInt(3, dni);
    sentencia.setString(4, Email);
    sentencia.setInt(5, telefono);
    sentencia.setString(6, Sector);
    sentencia.setString(7, Cargo);
    sentencia.setString(8, Rol);
   
    // 1. Corregido: Registrar el séptimo parámetro como SALIDA (Ejemplo si devuelve Texto)
    sentencia.registerOutParameter(9, java.sql.Types.VARCHAR);

    sentencia.execute();
   
    // 2. Opcional: Puedes leer lo que te devolvió la base de datos
    String respuestaBD = sentencia.getString(9);
   
    enviarRespuesta(intercambio, 201,
            "{\"mensaje\":\"Empleado guardado correctamente\", \"detalle\":\"" + respuestaBD + "\"}");

} catch (SQLException e) {
    e.printStackTrace();
    enviarRespuesta(intercambio, 500,
            "{\"error\":\"Error al guardar en la base de datos\"}");
}

            }
        });
           
// --------------------------------------------------------------------------  
servidor.createContext("/api/Empleados/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id = Integer.parseInt(datos.get("id"));
                    String nombre = datos.get("nombre");
                    String apellido = datos.get("apellido");
                    int dni = Integer.parseInt(datos.get("Dni"));
                    String email = datos.get("email");
                    int telefono = Integer.parseInt(datos.get("telefono"));
                    String sector = datos.get("sector");
                    String cargo = datos.get("cargo");
                    String rol = datos.get("rol");


                    if (dni <= 0 || telefono <= 0) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE empleados SET nombre = ?, apellido = ?, " + "dni = ?, email = ?, telefono = ?, sector = ?," + "cargo = ?, rol = ? WHERE ID_Empleado = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                       
                        sentencia.setString(1, nombre);
                        sentencia.setString(2, apellido);
                        sentencia.setInt(3, dni);
                        sentencia.setString(4, email);
                        sentencia.setInt(5, telefono);
                        sentencia.setString(6, sector);
                        sentencia.setString(7, cargo);
                        sentencia.setString(8, rol);
                        sentencia.setInt(9, id);
                       
                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Empleado actualizado correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro al empleado\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El DNI y el Telefono deben ser numeros validos\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });

servidor.createContext("/api/Empleados/eliminar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id = Integer.parseInt(datos.get("id"));

                    if (id <= 0) {
                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"ID no valido\"}");
                        return;
                    }

                    String sql = "DELETE FROM empleados WHERE ID_Empleado = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, id);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Empleado eliminado correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro el empleado.\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al eliminar de la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"No se pudo procesar la solicitud\"}");
                }
            }
        });



        // ----------------------------------------------------------------
        // ----------------------------------------------------------------
        servidor.createContext("/api/Vehiculos", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Vehiculos: " + ruta);
    
    if (!ruta.equals("/api/Vehiculos")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_vehiculos()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Vehiculo")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"precio\":\"").append(escaparJson(resultado.getString("Precio"))).append("\",");
            json.append("\"anio\":\"").append(escaparJson(resultado.getString("anio"))).append("\",");
            json.append("\"empleado\":\"").append(escaparJson(resultado.getString("ID_Empleado"))).append("\",");
            json.append("\"modelo\":\"").append(escaparJson(resultado.getString("Modelo"))).append("\",");
            json.append("\"marca\":\"").append(escaparJson(resultado.getString("Marca"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
         servidor.createContext("/api/Vehiculos/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }
                // Obtener los valores del formulario.
                String precio = datos.get("precio");
                String anio = datos.get("año");
                String empleado = datos.get("empleado");
                String modelo=datos.get("modelo");
                String marca=datos.get("marca");

                // Validar los campos.
                if (precio == null || anio == null
                        || empleado == null || modelo == null ||marca == null ||precio.trim().isEmpty()
                        || anio.trim().isEmpty()
                        || empleado.trim().isEmpty()|| modelo.trim().isEmpty()|| marca.trim().isEmpty()){
                        

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                

                // Preparar la consulta SQL.
                String sql = "INSERT INTO vehiculos "
                        + "(Precio, anio, ID_Empleado,Modelo,Marca) "
                        + "VALUES (?, ?, ?,?,?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/logistica32",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql)
                ) {
                    int precio2=Integer.parseInt(precio);
                   int anio2=Integer.parseInt(anio);
                   int empleado2=Integer.parseInt(empleado);
                    sentencia.setInt(1, precio2);
                    sentencia.setInt(2,anio2 );
                    sentencia.setInt(3, empleado2);
                    sentencia.setString(4, modelo);
                     sentencia.setString(5, marca);
                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Vehiculo guardado correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar el Vehiculo\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });    
         
        // -------------------------------------------------------------
        servidor.createContext("/api/Vehiculos/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id_vehiculo = Integer.parseInt(datos.get("id_vehiculo"));
                    int precio = Integer.parseInt(datos.get("precio"));
                    int año =Integer.parseInt(datos.get("año"));
                    String modelo = datos.get("modelo");
                    int id_empleado = Integer.parseInt(datos.get("id_empleado"));
                    String marca = datos.get("marca");
                   
                    
                    if (precio <= 0 || año <= 0 || id_empleado <= 0) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE vehiculos SET precio = ?, "
                        + "año = ?, modelo = ?, "
                        + "id_empleado = ?, marca = ?"
                        + "WHERE id_vehiculo = ?"
                    ;

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/logistica32", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, precio);
                        sentencia.setInt(2, año);
                        sentencia.setString(3, modelo);
                        sentencia.setInt(4, id_empleado);
                        sentencia.setString(5, marca);
                        sentencia.setInt(7, id_vehiculo);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Persona actualizada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"telefono debe ser numero valido\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });
        // ------------------------------------------------------------
        servidor.createContext("/api/VehiEnvi", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Union: " + ruta);
    
    if (!ruta.equals("/api/VehiEnvi")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_envio_vehiculo()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_EV")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"Envio\":\"").append(escaparJson(resultado.getString("ID_Envio"))).append("\",");
            json.append("\"Vehiculo\":\"").append(escaparJson(resultado.getString("ID_Vehiculo"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/VehiEnvi/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }
                   
                // Obtener los valores del formulario.
                String Envio = datos.get("Envio");
                String Vehiculo = datos.get("Vehiculo");
                // Validar los campos.
                if (Envio == null || Vehiculo == null
                        
                        || Envio.trim().isEmpty()
                        || Vehiculo.trim().isEmpty()) {

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                int envio;
                int paquete;

                try {
                    envio = Integer.parseInt(Envio);
                    paquete = Integer.parseInt(Vehiculo);
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"PAquete,Envio deben ser numeros enteros\"}");
                    return;
                }

                // Preparar la consulta SQL.
               String sql = "insert into envio_vehiculos (ID_Envio, ID_Vehiculo) values (?, ?)"; 

try (
    Connection conexion = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/logistica32",
            "root",
            ""
    );
    // Usamos PreparedStatement para el INSERT directo
    PreparedStatement sentencia = conexion.prepareStatement(sql);
) {
    sentencia.setInt(1, envio);
    sentencia.setInt(2, paquete);

    // Ejecuta la inserción en la base de datos
    sentencia.executeUpdate(); 
    
    // ¡CRUCIAL! Enviar la respuesta de éxito al Frontend para que funcione el JavaScript
    enviarRespuesta(intercambio, 201,
            "{\"mensaje\":\"Vehiculo asociado al envío correctamente\"}");

} catch (SQLException e) {
    e.printStackTrace();
    // Si sale el error de "Column count", entrará aquí
    enviarRespuesta(intercambio, 500,
            "{\"error\":\"Error en la base de datos: " + e.getMessage() + "\"}");
}

            }
        });
    servidor.createContext("/api/VehiPaq", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Union: " + ruta);
    
    if (!ruta.equals("/api/VehiPaq")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_envios_paquetes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_ep")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"Envio\":\"").append(escaparJson(resultado.getString("ID_Envio"))).append("\",");
            json.append("\"Paquete\":\"").append(escaparJson(resultado.getString("ID_Paquete"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/VehiPaq/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }
                   
                // Obtener los valores del formulario.
                String Envio = datos.get("Envio");
                String Paquete = datos.get("Paqeuete");
                // Validar los campos.
                if (Envio == null || Paquete == null
                        
                        || Envio.trim().isEmpty()
                        || Paquete.trim().isEmpty()) {

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                int envio;
                int paquete;

                try {
                    envio = Integer.parseInt(Envio);
                    paquete = Integer.parseInt(Paquete);
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"PAquete,Envio deben ser numeros enteros\"}");
                    return;
                }

                // Preparar la consulta SQL.
               String sql = "insert into envio_paquetes (ID_Envio, ID_Paquete) values (?, ?)"; 

try (
    Connection conexion = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/logistica32",
            "root",
            ""
    );
    // Usamos PreparedStatement para el INSERT directo
    PreparedStatement sentencia = conexion.prepareStatement(sql);
) {
    sentencia.setInt(1, envio);
    sentencia.setInt(2, paquete);

    // Ejecuta la inserción en la base de datos
    sentencia.executeUpdate(); 
    
    // ¡CRUCIAL! Enviar la respuesta de éxito al Frontend para que funcione el JavaScript
    enviarRespuesta(intercambio, 201,
            "{\"mensaje\":\"Paquete asociado al envío correctamente\"}");

} catch (SQLException e) {
    e.printStackTrace();
    // Si sale el error de "Column count", entrará aquí
    enviarRespuesta(intercambio, 500,
            "{\"error\":\"Error en la base de datos: " + e.getMessage() + "\"}");
}

            }
        });
    servidor.createContext("/api/Reportes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Reporte: " + ruta);
    
    if (!ruta.equals("/api/Reportes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_reportes()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Reporte")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"detalle\":\"").append(escaparJson(resultado.getString("detalle"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/Tickets", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Ticket: " + ruta);
    
    if (!ruta.equals("/api/Tickets")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_tickets()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Ticket")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
            json.append("\"Cliente\":\"").append(escaparJson(resultado.getString("ID_Cliente"))).append("\",");
            json.append("\"Fecha\":\"").append(escaparJson(resultado.getString("fecha"))).append("\",");
            json.append("\"Detalle\":\"").append(escaparJson(resultado.getString("detalle"))).append("\",");
            json.append("\"Total\":\"").append(escaparJson(resultado.getString("total"))).append("\",");
            json.append("\"Pago\":\"").append(escaparJson(resultado.getString("metodospago"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/RepoTicket", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Union: " + ruta);
    
    if (!ruta.equals("/api/RepoTicket")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "call mostrar_reportesTickets()";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        CallableStatement sentencia = conexion.prepareCall(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_rt")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
           
            json.append("\"Ticket\":\"").append(escaparJson(resultado.getString("ID_Ticket"))).append("\",");
            json.append("\"Reporte\":\"").append(escaparJson(resultado.getString("ID_Reporte"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
    servidor.createContext("/api/Almacenes", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
    String ruta = intercambio.getRequestURI().getPath();
    System.out.println("Contexto de Almacenes: " + ruta);
    
    if (!ruta.equals("/api/Almacenes")) {
        enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
        return;
    }
    
    String sql = "select * from almacenes;";
    StringBuilder json = new StringBuilder();
    
    try (
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistica32","root","");
        PreparedStatement sentencia = conexion.prepareStatement(sql);
        ResultSet resultado = sentencia.executeQuery()
    ) {
        json.append("[");
        boolean primero = true;
        
        while (resultado.next()) {
            if (!primero) {
                json.append(",");
            }
            json.append("{");
            json.append("\"id\":").append(resultado.getInt("ID_Almacen")).append(",");
            
            // CORRECCIÓN: Se agregaron las comillas \" al inicio y al final de los textos
           
            json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
            json.append("\"ciudad\":\"").append(escaparJson(resultado.getString("ciudad"))).append("\",");
            json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\"");
            json.append("}");
            primero = false;
        }
        json.append("]");
        
        // CORRECCIÓN EXTRA: Asegúrate de que enviarRespuesta configure el Content-Type como "application/json"
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        
        enviarRespuesta(intercambio, 200, json.toString());
        System.out.println("Llegó hasta aquí con éxito. JSON enviado.");
        
    } catch (SQLException e) {
        e.printStackTrace();
        enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
    }
}
        });
        //Iniciamos el servidor
        
        servidor.start();
        System.out.println("Servidor iniciado en http://localhost:8080");
    }
    
    private static String escaparJson(String texto) {

        if (texto == null) {
            return "";
        }

        return texto
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static void enviarRespuesta(
            HttpExchange intercambio,
            int codigo,
            String respuesta
    ) throws IOException {

        byte[] contenido = respuesta.getBytes(
                StandardCharsets.UTF_8
        );

        intercambio.getResponseHeaders().set(
                "Content-Type",
                "application/json; charset=UTF-8"
        );

        intercambio.sendResponseHeaders(
                codigo, contenido.length
        );

        try (OutputStream salida =
                intercambio.getResponseBody()) {

            salida.write(contenido);
        }
    }
    private static java.util.Map<String, String> leerParametros(
                HttpExchange intercambio) throws IOException {

            java.io.InputStream entrada = intercambio.getRequestBody();

            java.io.ByteArrayOutputStream buffer =
                    new java.io.ByteArrayOutputStream();

            int dato;

            while ((dato = entrada.read()) != -1) {
                buffer.write(dato);
            }

            String cuerpo = new String(
                    buffer.toByteArray(),
                    StandardCharsets.UTF_8
            );

            java.util.Map<String, String> parametros =
                    new java.util.HashMap<String, String>();

            String[] partes = cuerpo.split("&");

            for (String parte : partes) {
                String[] campo = parte.split("=", 2);

                String clave = java.net.URLDecoder.decode(
                        campo[0], "UTF-8"
                );

                String valor = "";

                if (campo.length > 1) {
                    valor = java.net.URLDecoder.decode(
                            campo[1], "UTF-8"
                    );
                }

                parametros.put(clave, valor);
            }

            return parametros;
        }
}
