/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Benjamin
 */
public class CiudadesDAO {
    public  ArrayList<String> listar(){
        ArrayList<String> ciudades=new ArrayList<>();
        String consulta_sql="call mostrar_ciudades()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    String s=resultado.getString("Nombre");
                    ciudades.add(s);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return ciudades;
            
            
        }
    public int buscar(String name) {
    String consulta_sql = "call buscar_ciudad(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setString(1, name);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            int p=resultado.getInt("ID_Ciudad");
            return p;
        } else {
            
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return -1;
}
}
