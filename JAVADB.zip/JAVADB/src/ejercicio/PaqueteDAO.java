/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Benjamin
 */
public class PaqueteDAO {
    public void eliminar_un_producto(int propa){
        String consulta_sql = "call borrar_producto_paquete(?,?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, propa);
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    }
    public void eliminar_todos_productos(int paquete){
        String consulta_sql = "call borrar_producto_paquete2(?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, paquete);
        sentencia_sql.executeUpdate();
        
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    }    
    public void agregar_producto(int producto,int paquete,int cantidad){
        String consulta_sql = "CALL agregar_productos_paquetes(?, ?,?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, producto);
        sentencia_sql.setInt(2, paquete);
        sentencia_sql.setInt(3, cantidad);
        sentencia_sql.registerOutParameter(4, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(4);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
    }
    public void mostrar_productos(int paquete){
        String consulta_sql="call Productos_paquete(?)";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                sentencia_sql.setInt(1, paquete);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    int propa=resultado.getInt("ID_Propa");
                    String marca=resultado.getString("marca");
                    String descripcion=resultado.getString("descripcion");
                    int stock=resultado.getInt("stock");
                    int cantidad=resultado.getInt("cantidad");
                    JOptionPane.showMessageDialog(null,"El identificador de la union(usar para borrar)"+propa+"\n La marca "+marca+" \n La descripcion "+descripcion+" \n El stock "+ stock+" \n La cantidad tomada "+cantidad);
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
    }
    
    public void insertar(Paquete c) throws SQLException {
    String consulta_sql = "CALL agregar_paquetes(?, ?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setDouble(1, c.getPeso());
        sentencia_sql.setDouble(2, c.getVolumen());
        sentencia_sql.setString(3, c.getFecha_ensamble());
        
        sentencia_sql.registerOutParameter(4, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(4);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}   
    public  ArrayList<Paquete> listar(){
        ArrayList<Paquete> paquetes=new ArrayList<>();
        String consulta_sql="call mostrar_paquetes()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Paquete p=new Paquete();
                    p.setId_paquete(resultado.getInt("ID_Paquete"));
                    p.setFecha_ensamble(resultado.getString("fecha_ensamble"));
                    p.setPeso(resultado.getDouble("peso"));
                    p.setVolumen(resultado.getDouble("volumen"));
                    paquetes.add(p);
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return paquetes;
            
            
        }
   public Paquete buscar(int id) {
    String consulta_sql = "call buscar_paquetes(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            Paquete p=new Paquete();
                    p.setId_paquete(resultado.getInt("ID_Paquete"));
                    p.setFecha_ensamble(resultado.getString("fecha_ensamble"));
                    p.setPeso(resultado.getDouble("peso"));
                    p.setVolumen(resultado.getDouble("volumen"));
            return p;
        } else {
            System.out.println("No se encontró ningún envio con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    public void eliminar(int id) {
    String consulta_sql = "call borrar_paquete(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
   public void actualizar(Paquete c) {
    String consulta_sql = "call editar_paquetes(?,?,?,?,?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, c.getId_paquete());
        sentencia_sql.setDouble(2, c.getPeso());
        sentencia_sql.setDouble(3, c.getVolumen());
        sentencia_sql.setString(4, c.getFecha_ensamble());
        
        sentencia_sql.registerOutParameter(5, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(5);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}
}
