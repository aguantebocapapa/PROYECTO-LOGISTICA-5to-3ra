/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Redes-20
 */
public class ClienteDAO {
    public void insertar(Cliente c) throws SQLException {
    String consulta_sql = "CALL agregar_clientes(?, ?, ?, ?, ?, ?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setString(1, c.getNombre());
        sentencia_sql.setString(2, c.getApellido());
        sentencia_sql.setString(3, c.getCod_postal());
        sentencia_sql.setString(4, c.getDireccion());
        sentencia_sql.setString(5, c.getDni());
        sentencia_sql.setString(6, c.getEmail());
        sentencia_sql.setString(7, c.getNumero_telefono());
        
        sentencia_sql.registerOutParameter(8, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(8);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        System.out.println("Empleado guardado exitosamente");
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}
    public  ArrayList<Cliente> listar(){
        ArrayList<Cliente> clientes=new ArrayList<>();
        String consulta_sql="call mostrar_clientes()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Cliente p=new Cliente();
                    p.setIdCliente(resultado.getInt("ID_Cliente"));
                    p.setNombre(resultado.getString("Nombre"));
                    p.setApellido(resultado.getString("Apellido"));
                    p.setDni(resultado.getString("Dni"));
                    p.setEmail(resultado.getString("email"));
                    p.setNumero_telefono(resultado.getString("telefono"));
                    p.setCod_postal(resultado.getString("codigo"));
                    p.setDireccion(resultado.getString("direccion"));
                    clientes.add(p);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return clientes;
            
            
        }
   public Cliente buscar(int id) {
    String consulta_sql = "call buscar_clientes(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            Cliente p=new Cliente();
                    p.setIdCliente(resultado.getInt("ID_Cliente"));
                    p.setNombre(resultado.getString("Nombre"));
                    p.setApellido(resultado.getString("Apellido"));
                    p.setDni(resultado.getString("Dni"));
                    p.setEmail(resultado.getString("email"));
                    p.setNumero_telefono(resultado.getString("telefono"));
                    p.setCod_postal(resultado.getString("codigo"));
                    p.setDireccion(resultado.getString("direccion"));
            
            System.out.println("------------------");
            return p;
        } else {
            System.out.println("No se encontró ningún empleado con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    public void eliminar(int id) {
    String consulta_sql = "call borrar_cliente(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Registro eliminado");
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
   public void actualizar(Cliente c) {
    String consulta_sql = "call editar_cliente(?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, c.getIdCliente());
        sentencia_sql.setString(2, c.getNombre());
        sentencia_sql.setString(3, c.getApellido());
        sentencia_sql.setString(4, c.getCod_postal());
        sentencia_sql.setString(5, c.getDireccion());
        sentencia_sql.setString(6, c.getDni());
        sentencia_sql.setString(7, c.getEmail());
        sentencia_sql.setString(8, c.getNumero_telefono());
        
        sentencia_sql.registerOutParameter(9, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(9);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Datos actualizados correctamente");
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}
}
