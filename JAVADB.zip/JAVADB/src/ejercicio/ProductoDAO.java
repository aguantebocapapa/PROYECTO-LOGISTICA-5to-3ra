/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class ProductoDAO {
    public void insertar(Producto p){
        String consulta_sql = "CALL agregar_productos(?, ?, ?, ?, ?,?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setString(1, p.getNombremarca());
        sentencia_sql.setString(2, p.getDescripcion());
        sentencia_sql.setDouble(3, p.getPrecio());
        sentencia_sql.setInt(4, p.getStock());
        sentencia_sql.setString(5, p.getTipo());
        
        
        sentencia_sql.registerOutParameter(6, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(6);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}
    
     public  ArrayList<Producto> listar(){
        ArrayList<Producto> productos =new ArrayList<>();
        String consulta_sql="call mostrar_productos()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Producto p=new Producto();
                    p.setIdproducto(resultado.getInt("ID_Producto"));
                    p.setNombremarca(resultado.getString("Marca"));
                    p.setDescripcion(resultado.getString("Descripcion"));
                    p.setPrecio(resultado.getDouble("Precio"));
                    p.setStock(resultado.getInt("Stock"));
                    p.setTipo(resultado.getString("Categoria"));
                    productos.add(p);
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return productos;
            
            
        }
     
    public Producto buscar(int id) {
    String consulta_sql = "call buscar_productos(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
                Producto p=new Producto();
                    p.setIdproducto(resultado.getInt("ID_Producto"));
                    p.setNombremarca(resultado.getString("Marca"));
                    p.setDescripcion(resultado.getString("Descripcion"));
                    p.setPrecio(resultado.getDouble("Precio"));
                    p.setStock(resultado.getInt("Stock"));
                    p.setTipo(resultado.getString("Categoria"));
            return p;
        } else {
            System.out.println("No se encontró ningún envio con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    
    public void eliminar(int id) {
    String consulta_sql = "call borrar_producto(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
    public void actualizar(Producto p) {
    String consulta_sql = "call editar_productos(?, ?, ?, ?, ?,?,?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, p.getIdproducto());
        sentencia_sql.setString(2, p.getNombremarca());
        sentencia_sql.setString(3, p.getDescripcion());
        sentencia_sql.setDouble(4, p.getPrecio());
        sentencia_sql.setInt(5, p.getStock());
        sentencia_sql.setString(6, p.getTipo());
        
        sentencia_sql.registerOutParameter(7, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(7);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}

}
