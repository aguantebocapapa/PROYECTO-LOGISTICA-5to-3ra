/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Benjamin
 */
public class AdheridoDAO {
    public void insertar(Empresas_Adheridas c) throws SQLException {
    String consulta_sql = "CALL agregar_empresa_adherida(?, ?, ?, ?, ?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setString(1, c.getNombre());
        sentencia_sql.setString(2, c.getCuil());
        sentencia_sql.setString(3, c.getDireccion());
        sentencia_sql.setInt(4, c.getTelefono());
        sentencia_sql.setString(5, c.getRubro());
        sentencia_sql.setString(6, c.getDuenio());
        
        sentencia_sql.registerOutParameter(7, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(7);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        System.out.println("Empleado guardado exitosamente");
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}
    public  ArrayList<Empresas_Adheridas> listar(){
        ArrayList<Empresas_Adheridas> adherido=new ArrayList<>();
        String consulta_sql="call mostrar_adheridos()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Empresas_Adheridas p=new Empresas_Adheridas();
                    p.setId_empresa(resultado.getInt("ID_empresa"));
                    p.setNombre(resultado.getString("nombre"));
                    p.setCuil(resultado.getString("cuit"));
                    p.setDireccion(resultado.getString("direccion"));
                    p.setDuenio(resultado.getString("duenio"));
                    p.setRubro(resultado.getString("rubro"));
                    p.setTelefono(resultado.getInt("telefono"));
                    adherido.add(p);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return adherido;
            
            
        }
   public Empresas_Adheridas buscar(int id) {
    String consulta_sql = "call buscar_Adheridos(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
             Empresas_Adheridas p=new Empresas_Adheridas();
                    p.setId_empresa(resultado.getInt("ID_empresa"));
                    p.setNombre(resultado.getString("nombre"));
                    p.setCuil(resultado.getString("cuit"));
                    p.setDireccion(resultado.getString("direccion"));
                    p.setDuenio(resultado.getString("duenio"));
                    p.setRubro(resultado.getString("rubro"));
                    p.setTelefono(resultado.getInt("telefono"));
                    return p;
        } else {
            System.out.println("No se encontró ningún empleado con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    public void eliminar(int id) {
    String consulta_sql = "call eliminar_empresa_adherida(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Registro eliminado");
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
   public void actualizar(Empresas_Adheridas c) {
    String consulta_sql = "call editar_empresa_adherida(?, ?, ?, ?, ?, ?, ?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, c.getId_empresa());
        sentencia_sql.setString(2, c.getNombre());
        sentencia_sql.setString(3, c.getCuil());
        sentencia_sql.setString(4, c.getDireccion());
        sentencia_sql.setInt(5, c.getTelefono());
        sentencia_sql.setString(6, c.getRubro());
        sentencia_sql.setString(7, c.getDuenio());
        
        sentencia_sql.registerOutParameter(8, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(8);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Datos actualizados correctamente");
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}
}
