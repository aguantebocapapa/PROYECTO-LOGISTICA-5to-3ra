package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Redes-20
 */
public class ReporteDAO {
    public void insertar(Reporte r) throws SQLException {
    String consulta_sql = "CALL agregar_reportes(?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setString(1, r.getDetalle());
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        System.out.println("Reporte guardado exitosamente");
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}
    public  ArrayList<Reporte> listar(){
        ArrayList<Reporte> reportes=new ArrayList<>();
        String consulta_sql="call mostrar_reportes()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Reporte rep=new Reporte();
                    rep.setIdReporte(resultado.getInt("ID_Reporte"));
                    rep.setDetalle(resultado.getString("detalle"));

                    reportes.add(rep);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return reportes;
            
            
        }
   public Reporte buscar(int id) {
    String consulta_sql = "call buscar_reportess(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            Reporte rep=new Reporte();
                    rep.setIdReporte(resultado.getInt("ID_Reporte"));
                    rep.setDetalle(resultado.getString("detalle"));
            
            System.out.println("------------------");
            return rep;
        } else {
            System.out.println("No se encontró ningún reporte con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    public void eliminar(int id) {
    String consulta_sql = "call eliminarReporte(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Registro eliminado");
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
   public void actualizar(Reporte rep) {
    String consulta_sql = "call editar_reporte(?, ?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, rep.getIdReporte());
        sentencia_sql.setString(2, rep.getDetalle());
        
        sentencia_sql.registerOutParameter(3, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(3);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Datos actualizados correctamente");
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}
   
    public void mostrar_tickets(int id){
        String consulta_sql="call Tickets_reporte(?)";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                sentencia_sql.setInt(1, id);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    int id_union=resultado.getInt("ID_rt");
                    String nombre=resultado.getString("Nombre");
                    String apellido=resultado.getString("Apellido");
                    String detalle=resultado.getString("detalle");
                    int total=resultado.getInt("total");
                    String pago=resultado.getString("metodospago");
                    JOptionPane.showMessageDialog(null,"Id de la union(para borrar)"+id_union+"\n Nombre del cliente: "+nombre+"\n Apellido del clientes: " + apellido+"\n Detalle: " + detalle+"\n Total: "+total+"\n Metodo de pago: " + pago);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
    }   
    public void agregar_ticket(int id_reporte, int id_ticket){
        String consulta_sql = "CALL agregarReportes_Ticket(?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_reporte);
        sentencia_sql.setInt(2, id_ticket);
        
        sentencia_sql.registerOutParameter(3, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(3);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
    }    
    
    public void eliminar_reporteticket(int id_rep) {
    String consulta_sql = "call eliminar_ReportesTicket(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_rep);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
    
    public void eliminar_todosreportesticket(int id_rep) {
    String consulta_sql = "call eliminar_ReportesTicket2(?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_rep);
        sentencia_sql.executeUpdate();
        
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}    
}