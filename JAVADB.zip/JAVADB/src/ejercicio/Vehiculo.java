package ejercicio;
import javax.swing.JOptionPane;

public  class Vehiculo {
   private int idvehiculo;
   private int precio;
   private int anio;
   private int idEmpleado;
   private String modelo;
   private String marca;
    
   public Vehiculo(){
       
   }
    public Vehiculo(int precio, int anio, int idEmpleado, String modelo, String marca) {
        this.precio = precio;
        this.anio = anio;
        this.idEmpleado = idEmpleado;
        this.modelo = modelo;
        this.marca = marca;
    }

    public int getIdvehiculo() {
        return idvehiculo;
    }

    public void setIdvehiculo(int idvehiculo) {
        this.idvehiculo = idvehiculo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
   
   

}
