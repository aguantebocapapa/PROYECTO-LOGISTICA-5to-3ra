/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Benjamin
 */
public class UsuarioDAO {
    public void insertar(Usuario c) throws SQLException {
    String consulta_sql = "CALL crear_usuario(?,?,?,?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setString(1, c.getNombre());
        sentencia_sql.setString(2, c.getApellido());
        sentencia_sql.setString(3, c.getEmail());
        sentencia_sql.setString(4, c.getContrasenia());      
        sentencia_sql.executeUpdate();
        System.out.println("Empleado guardado exitosamente");
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}
    public Usuario validarlogin(String usuario,String password){
        String sql="call validar_login(?,?)";
        try{
            Connection conexion=Conexion.conectar();
            CallableStatement sentencia = conexion.prepareCall(sql);
            sentencia.setString(1, usuario);
            sentencia.setString(2, password);
            ResultSet resultado=sentencia.executeQuery();
            if(resultado.next()){
                Usuario c=new Usuario();
                c.setId(resultado.getInt("id_usuario"));
                c.setNombre(resultado.getString("nombre"));
                c.setApellido(resultado.getString("apellido"));
                c.setEmail(resultado.getString("email"));
                c.setContrasenia(resultado.getString("contrasenia"));
                JOptionPane.showMessageDialog(null,"Ha entrado");
                return c;
            }
        }catch (SQLException ex){
            System.out.println("ERROR: "+ex.getMessage());
        }
    
return null;
}
    public void  modificar_usuario(Usuario c){
        String consulta_sql ="call editar_usuario(?,?,?,?,?)";
            try{
                Connection conexion=Conexion.conectar();
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                sentencia_sql.setInt(1, c.getId());
                sentencia_sql.setString(2, c.getNombre());
                sentencia_sql.setString(3,c.getApellido());
                sentencia_sql.setString(4, c.getEmail());
                sentencia_sql.setString(5, c.getContrasenia());
                sentencia_sql.executeUpdate();
                System.out.println("Datos actualizados correctamente");
                
                
            } catch (SQLException ex) {
                System.out.println("Error " + ex.getMessage());
        }
        }
}
