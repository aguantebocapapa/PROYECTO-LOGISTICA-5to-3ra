
package ejercicio;

import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Cliente extends Persona{
    private int idCliente;
    private String direccion;
    private  String cod_postal;

    public Cliente( String direccion, String cod_postal, String nombre, String apellido, String dni, String email, String numero_telefono) {
        super(nombre, apellido, dni, email, numero_telefono);
        this.direccion = direccion;
        this.cod_postal = cod_postal;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCod_postal() {
        return cod_postal;
    }

    public void setCod_postal(String cod_postal) {
        this.cod_postal = cod_postal;
    }

   

   
    
    @Override
    public void mostrarPersona(){
        JOptionPane.showMessageDialog(null, "El nombre es: " + getNombre()
                + "\n Su apellido es: " + getApellido()
                + "\n Su DNI es: " + getDni()
                + "\n Su Email es: " + getEmail()
                + "\n Su numero de telefono es: " + getNumero_telefono()
                +"El id del cliente es:"+idCliente
                + "\n Su direccion es " + getDireccion()
                + "\n Su codigo postale es: " + getCod_postal()
        );
    }
    
    
    
   
}
