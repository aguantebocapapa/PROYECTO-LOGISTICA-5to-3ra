
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class VehiculoDAO {
    
    public void insertar(Vehiculo v)throws SQLException {
        String consulta_sql = "CALL crear_vehiculo(?, ?, ?, ?, ?, ?)"; 
        
        try{
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            
            
            sentencia_sql.setInt(1, v.getPrecio());
            sentencia_sql.setInt(2, v.getAnio());
            sentencia_sql.setInt(3, v.getIdEmpleado());
            sentencia_sql.setString(4, v.getModelo());
            sentencia_sql.setString(5, v.getMarca());
            
            sentencia_sql.registerOutParameter(6, java.sql.Types.VARCHAR);
            sentencia_sql.executeUpdate();
            String mensajeRespuesta = sentencia_sql.getString(6);
            System.out.println("Respuesta del servidor: " + mensajeRespuesta);
            System.out.println("Vehiculo guardado correctamente");
        }catch(SQLException ex){
            System.out.println("ERROR "+ ex.getMessage());
        }
    }
    
    public ArrayList <Vehiculo> listar(){
        ArrayList <Vehiculo> lista_vehiculo = new ArrayList<>();
        String consulta_sql="call mostrar_vehiculos()";
        try{
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            ResultSet resultado=sentencia_sql.executeQuery();
            
            while (resultado.next()){
                Vehiculo v = new Vehiculo();
                
                v.setIdvehiculo(resultado.getInt("ID_Vehiculo"));
                v.setPrecio(resultado.getInt("Precio"));
                v.setAnio(resultado.getInt("anio"));
                v.setIdEmpleado(resultado.getInt("ID_Empleado"));
                v.setModelo(resultado.getString("Modelo"));
                v.setMarca(resultado.getString("Marca"));
                
                
                
                
                lista_vehiculo.add(v);
                System.out.println("~~~~~~~~~~~~~~~~~~");
            }
        }catch (SQLException ex){
            System.out.println("ERROR "+ ex.getMessage());
        }
        return lista_vehiculo;
    }
    
    public void actualizar (Vehiculo v){
         String consulta_sql = "call editar_vehiculos (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            
            sentencia_sql.setInt(1, v.getIdvehiculo());
            sentencia_sql.setInt(2, v.getPrecio());
            sentencia_sql.setInt(3, v.getAnio());
            sentencia_sql.setInt(4, v.getIdEmpleado());
            sentencia_sql.setString(5, v.getModelo());
            sentencia_sql.setString(6, v.getMarca());
            
            sentencia_sql.registerOutParameter(7, java.sql.Types.VARCHAR);
            sentencia_sql.executeUpdate();
            String respuesta = sentencia_sql.getString(7);
            System.out.println("Respuesta de la BD: " + respuesta);
            System.out.println("Datos actualizados exitoamnete");
            
        }catch (SQLException ex){
            System.out.println("ERROR "+ ex.getMessage());
        }
    
    }
    
    public Vehiculo buscar(int id) {
    String consulta_sql = "call buscar_vehiculo(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            Vehiculo v =new Vehiculo();
                v.setIdvehiculo(resultado.getInt("ID_Vehiculo"));
                v.setPrecio(resultado.getInt("Precio"));
                v.setAnio(resultado.getInt("anio"));
                v.setIdEmpleado(resultado.getInt("ID_Empleado"));
                v.setModelo(resultado.getString("Modelo"));
                v.setMarca(resultado.getString("Marca"));
            
            System.out.println("------------------");
            return v;
        } else {
            System.out.println("No se encontró ningún vehiculo con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    
    public void eliminar(int id) {
    String consulta_sql = "call eliminar_vehiculo (?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Vehiculo eliminado");
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
}
