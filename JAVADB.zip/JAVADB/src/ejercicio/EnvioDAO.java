/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Benjamin
 */
public class EnvioDAO {
    public void eliminar_un_paquete(int id_envio,int id_paquete){
        String consulta_sql = "call eliminar_envio_paquete(?,?,?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_envio);
        sentencia_sql.setInt(2, id_paquete);
        sentencia_sql.registerOutParameter(3, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    }
    public void eliminar_todos_paquetes(int id_envio){
        String consulta_sql = "call eliminar_paquetes2(?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_envio);
        sentencia_sql.executeUpdate();
        
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    }
    public void eliminar_un_vehiculo(int env_vehic){
        String consulta_sql = "call eliminar_env_vehic(?,?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, env_vehic);
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    }   
    public void eliminar_todos_vehiculos(int id_envio){
        String consulta_sql = "call eliminar_env_vehic2(?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_envio);

        sentencia_sql.executeUpdate();
     
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    }
    
    public void agregar_paquete(int id_envio,int id_paquete){
        String consulta_sql = "CALL agregar_envio_paquete(?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_envio);
        sentencia_sql.setInt(2, id_paquete);
        
        sentencia_sql.registerOutParameter(3, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(8);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
    }
    public void agregar_vehiculo(int id_envio,int id_vehiculo){
        String consulta_sql = "CALL crear_enviovehiculos(?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_envio);
        sentencia_sql.setInt(2, id_vehiculo);
        
        sentencia_sql.registerOutParameter(3, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(8);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
    }
    public void mostrar_paquetes(int id_envio){
        String consulta_sql="call paqutes_envio(?)";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                sentencia_sql.setInt(1, id_envio);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    int paquete=resultado.getInt("ID_Paquete");
                    double peso=resultado.getDouble("peso");
                    double volumen=resultado.getDouble("volumen");
                    JOptionPane.showMessageDialog(null, "El paquete de ID"+paquete+"\n Con el peso "+peso+"\n con el volumen " + volumen);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
    }
    public void mostrar_vehiculos(int id_envio){
        String consulta_sql="call Vehiculos_envio(?)";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                sentencia_sql.setInt(1, id_envio);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    int env_veh=resultado.getInt("ID_EV");
                    String marca=resultado.getString("Marca");
                    String modelo=resultado.getString("Modelo");
                    int vehiculo=resultado.getInt("ID_Vehiculo");
                    JOptionPane.showMessageDialog(null, "El id intermediario(usar para borrar) " + env_veh+"\n El identifiacador"
                            + " del vehiculo "+vehiculo+" \n la marca del vehiculo: "+ marca+"\n El modelo del vehiculo : "+modelo);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
    }
    
    public void insertar(Envio c) throws SQLException {
    String consulta_sql = "CALL verificar_envio(?, ?, ?, ?, ?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setString(1, c.getFecha());
        sentencia_sql.setInt(2, c.getOrigen());
        sentencia_sql.setInt(3, c.getDestino());
        sentencia_sql.setInt(4, c.getEmpresa_adherida());
        sentencia_sql.setString(5, c.getEstado());
        sentencia_sql.setInt(6, c.getCliente());
        
        sentencia_sql.registerOutParameter(7, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(8);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}   
    public  ArrayList<Envio> listar(){
        ArrayList<Envio> envios=new ArrayList<>();
        String consulta_sql="call mostrar_envios()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Envio p=new Envio();
                    p.setNumEnvio(resultado.getInt("ID_Envio"));
                    p.setFecha(resultado.getString("Fecha"));
                    p.setOrigen(resultado.getInt("Origen"));
                    p.setDestino(resultado.getInt("Destino"));
                    p.setEmpresa_adherida(resultado.getInt("ID_Empresa"));
                    p.setEstado(resultado.getString("estado"));
                    p.setCliente(resultado.getInt("ID_Cliente"));
                    envios.add(p);
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return envios;
            
            
        }
   public Envio buscar(int id) {
    String consulta_sql = "call buscar_envio(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            Envio p=new Envio();
                    p.setNumEnvio(resultado.getInt("ID_Envio"));
                    p.setFecha(resultado.getString("Fecha"));
                    p.setOrigen(resultado.getInt("Origen"));
                    p.setDestino(resultado.getInt("Destino"));
                    p.setEmpresa_adherida(resultado.getInt("ID_Empresa"));
                    p.setEstado(resultado.getString("estado"));
                    p.setCliente(resultado.getInt("ID_Cliente"));
            return p;
        } else {
            System.out.println("No se encontró ningún envio con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    public void eliminar(int id) {
    String consulta_sql = "call eliminar_envio(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
   public void actualizar(Envio c) {
    String consulta_sql = "call editar_envio(?,?, ?, ?, ?, ?, ?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, c.getNumEnvio());
        sentencia_sql.setString(2, c.getFecha());
        sentencia_sql.setInt(3, c.getOrigen());
        sentencia_sql.setInt(4, c.getDestino());
        sentencia_sql.setInt(5, c.getEmpresa_adherida());
        sentencia_sql.setString(6, c.getEstado());
        sentencia_sql.setInt(7, c.getCliente());
        
        sentencia_sql.registerOutParameter(8, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(9);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}
}
