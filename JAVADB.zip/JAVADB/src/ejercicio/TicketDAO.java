package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Redes-20
 */
public class TicketDAO {
    public void insertar(Ticket t) throws SQLException {
    String consulta_sql = "CALL agregarTickett(?, ?, ?, ?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, t.getCliente());
        sentencia_sql.setString(2, t.getFecha());
        sentencia_sql.setString(3, t.getDetalle());
        sentencia_sql.setInt(4, t.getTotal());
        sentencia_sql.setString(5, t.getPago());
        
        sentencia_sql.registerOutParameter(6, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(6);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}
    public  ArrayList<Ticket> listar(){
        ArrayList<Ticket> tickets=new ArrayList<>();
        String consulta_sql="call mostrar_tickets()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Ticket tic=new Ticket();
                    tic.setIdticket(resultado.getInt("ID_Ticket"));
                    tic.setCliente(resultado.getInt("ID_Cliente"));
                    tic.setFecha(resultado.getString("fecha"));
                    tic.setDetalle(resultado.getString("detalle"));
                    tic.setTotal(resultado.getInt("total"));
                    tic.setPago(resultado.getString("metodospago"));

                    tickets.add(tic);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return tickets;
            
            
        }
   public Ticket buscar_Tickets(int id) {
    String consulta_sql = "call buscar_Tickets(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            Ticket tic=new Ticket();
                    tic.setIdticket(resultado.getInt("ID_Ticket"));
                    tic.setCliente(resultado.getInt("ID_Cliente"));
                    tic.setFecha(resultado.getString("fecha"));
                    tic.setDetalle(resultado.getString("detalle"));
                    tic.setTotal(resultado.getInt("total"));
                    tic.setPago(resultado.getString("metodospago"));
            System.out.println("------------------");
            return tic;
        } else {
            System.out.println("No se encontró ningún ticket con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    public void eliminar(int id) {
    String consulta_sql = "call eliminarTicket(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    public void eliminar_porCliente(int id_cliente) {
    String consulta_sql = "call eliminarTicket2(?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id_cliente);
        
        sentencia_sql.executeUpdate();
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
   public void actualizar(Ticket tic) {
    String consulta_sql = "call editar_ticket(?, ?, ?, ?, ?, ?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, tic.getIdticket());
        sentencia_sql.setInt(2, tic.getCliente());
        sentencia_sql.setString(3, tic.getFecha());
        sentencia_sql.setString(4, tic.getDetalle());
        sentencia_sql.setInt(5, tic.getTotal());
        sentencia_sql.setString(6, tic.getPago());
        
        sentencia_sql.registerOutParameter(7, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(7);
        System.out.println("Respuesta de la BD: " + respuesta);
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}
}