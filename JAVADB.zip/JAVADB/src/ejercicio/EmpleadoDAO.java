/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Redes-20
 */
//Nombre, Apellido, Dni, email, telefono, sector, cargo, rol
public class EmpleadoDAO {
    public void insertar(Empleado c) throws SQLException {
    String consulta_sql = "CALL agregar_empleados(?, ?, ?, ?, ?, ?, ?, ?, ?)"; 
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setString(1, c.getNombre());
        sentencia_sql.setString(2, c.getApellido());
        sentencia_sql.setString(3, c.getDni());
        sentencia_sql.setString(4, c.getEmail());
        sentencia_sql.setString(5, c.getNumero_telefono());
        sentencia_sql.setString(6, c.getSector());
        sentencia_sql.setString(7, c.getCargo());
        sentencia_sql.setString(8, c.getRol());
        
        sentencia_sql.registerOutParameter(9, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String mensajeRespuesta = sentencia_sql.getString(9);
        System.out.println("Respuesta del servidor: " + mensajeRespuesta);
        System.out.println("Empleado guardado exitosamente");
        
    } catch (SQLException ex) {
        System.out.println("ERROR :" + ex.getMessage());
    }
}
    public  ArrayList<Empleado> listar(){
        ArrayList<Empleado> empleados=new ArrayList<>();
        String consulta_sql="call mostrar_empleados()";

            Connection conexion=Conexion.conectar();
            try {
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
                ResultSet resultado=sentencia_sql.executeQuery();
                while(resultado.next()){
                    Empleado p=new Empleado();
                    p.setIdempleado(resultado.getInt("ID_Empleado"));
                    p.setNombre(resultado.getString("Nombre"));
                    p.setApellido(resultado.getString("Apellido"));
                    p.setDni(resultado.getString("Dni"));
                    p.setEmail(resultado.getString("email"));
                    p.setNumero_telefono(resultado.getString("telefono"));
                    p.setSector(resultado.getString("sector"));
                    p.setCargo(resultado.getString("cargo"));
                    p.setRol(resultado.getString("rol"));
                    empleados.add(p);
                    System.out.println("------------------");
                }
            } catch (SQLException ex) {
                System.out.println("ERROR "+ex.getMessage());
            }
            return empleados;
            
            
        }
   public Empleado buscar(int id) {
    String consulta_sql = "call buscar_empleado(?)";
    Connection conexion = Conexion.conectar();
    
    try {
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        sentencia_sql.setInt(1, id);
        ResultSet resultado = sentencia_sql.executeQuery();
        
        if (resultado.next()) { 
            Empleado p = new Empleado();
            p.setIdempleado(resultado.getInt("ID_Empleado"));
            p.setNombre(resultado.getString("Nombre"));
            p.setApellido(resultado.getString("Apellido"));
            p.setDni(resultado.getString("Dni"));
            p.setEmail(resultado.getString("email"));
            p.setNumero_telefono(resultado.getString("telefono"));
            p.setSector(resultado.getString("sector"));
            p.setCargo(resultado.getString("cargo"));
            p.setRol(resultado.getString("rol"));
            
            System.out.println("------------------");
            return p;
        } else {
            System.out.println("No se encontró ningún empleado con el ID: " + id);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return null;
}
    public void eliminar(int id) {
    String consulta_sql = "call eliminar_empleado(?, ?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, id);
        
        sentencia_sql.registerOutParameter(2, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(2);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Registro eliminado");
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}
    
   public void actualizar(Empleado c) {
    String consulta_sql = "call editar_empleados(?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
    
    try {
        Connection conexion = Conexion.conectar();
        CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
        
        sentencia_sql.setInt(1, c.getIdempleado());
        sentencia_sql.setString(2, c.getNombre());
        sentencia_sql.setString(3, c.getApellido());
        sentencia_sql.setString(4, c.getDni());
        sentencia_sql.setString(5, c.getEmail());
        sentencia_sql.setString(6, c.getNumero_telefono());
        sentencia_sql.setString(7, c.getSector());
        sentencia_sql.setString(8, c.getCargo());
        sentencia_sql.setString(9, c.getRol());
        
        sentencia_sql.registerOutParameter(10, java.sql.Types.VARCHAR);
        
        sentencia_sql.executeUpdate();
        
        String respuesta = sentencia_sql.getString(9);
        System.out.println("Respuesta de la BD: " + respuesta);
        System.out.println("Datos actualizados correctamente");
        
    } catch (SQLException ex) {
        System.out.println("Error " + ex.getMessage());
    }
}
}
