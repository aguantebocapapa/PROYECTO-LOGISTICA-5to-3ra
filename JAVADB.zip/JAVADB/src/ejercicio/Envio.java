
package ejercicio;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Envio {
    
    private int numEnvio;
    private String fecha;
    private String origen;
    private String destino;
    private  String estado;
    private int empresa_adherida;
    private int cliente;

    public Envio(String fecha, String origen, String destino, String estado, int empresa_adherida, int cliente) {
        this.fecha = fecha;
        this.origen = origen;
        this.destino = destino;
        this.estado = estado;
        this.empresa_adherida = empresa_adherida;
        this.cliente = cliente;
    }

    public int getNumEnvio() {
        return numEnvio;
    }

    public void setNumEnvio(int numEnvio) {
        this.numEnvio = numEnvio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getEmpresa_adherida() {
        return empresa_adherida;
    }

    public void setEmpresa_adherida(int empresa_adherida) {
        this.empresa_adherida = empresa_adherida;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }
    
    
}
