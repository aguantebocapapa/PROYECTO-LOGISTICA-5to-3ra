
package ejercicio;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Envio {
    
    private int numEnvio;
    private String fecha;
    private int origen;
    private int destino;
    private  String estado;
    private int empresa_adherida;
    private int cliente;

    public Envio() {
    }

    public int getNumEnvio() {
        return numEnvio;
    }

    public void setNumEnvio(int numEnvio) {
        this.numEnvio = numEnvio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getOrigen() {
        return origen;
    }

    public void setOrigen(int origen) {
        this.origen = origen;
    }

    public int getDestino() {
        return destino;
    }

    public void setDestino(int destino) {
        this.destino = destino;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getEmpresa_adherida() {
        return empresa_adherida;
    }

    public void setEmpresa_adherida(int empresa_adherida) {
        this.empresa_adherida = empresa_adherida;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }



    
    
    
}
