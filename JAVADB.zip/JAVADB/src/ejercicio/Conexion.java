/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Redes-04
 */
public class Conexion {
    private static final String URL="jdbc:mysql://localhost:3306/Logistica32";
    private static final String USUARIO="root";
    private static final String PASSWORD="";
    public static Connection conectar(){
        
            Connection conexion;
        try {
            conexion = DriverManager.getConnection(URL,USUARIO,PASSWORD);
            return conexion;
        } catch (SQLException ex) {
                System.out.println("ERROR: "+ex.getMessage());
                return null;
        }
            
        
        
    }
}
